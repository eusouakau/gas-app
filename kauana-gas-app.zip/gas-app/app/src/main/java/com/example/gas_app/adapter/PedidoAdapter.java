package com.example.gas_app.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gas_app.R;
import com.example.gas_app.model.Pedido;

import java.util.List;

public class PedidoAdapter extends RecyclerView.Adapter<PedidoAdapter.MyViewHolder> {
    List<Pedido> listaPedidos;
    Context context;
    public PedidoAdapter(List<Pedido> pedido) {
        this.listaPedidos = pedido;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View itemList = LayoutInflater.from(viewGroup.getContext()).
                inflate(R.layout.adapter_card, viewGroup, false);

        this.context = viewGroup.getContext();
        return new MyViewHolder(itemList);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, @SuppressLint("RecyclerView") int position) {
        Pedido p = listaPedidos.get(position);
        myViewHolder.nome.setText(p.getNome());
        myViewHolder.endereco.setText(p.getEndereco());
        myViewHolder.nomeProd.setText(p.getNomeProd());
        myViewHolder.total.setText(p.getTotal());

    }

    @Override
    public int getItemCount() {
        return listaPedidos.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nome;
        TextView endereco;
        TextView nomeProd;
        TextView total;

        public MyViewHolder(View itemView){
            super(itemView);
            nome = itemView.findViewById(R.id.textViewNome);
            endereco = itemView.findViewById(R.id.textViewEndereco);
            nomeProd = itemView.findViewById(R.id.textViewNomeProd);
            total = itemView.findViewById(R.id.textViewTotal);
            
        }
    }
}

