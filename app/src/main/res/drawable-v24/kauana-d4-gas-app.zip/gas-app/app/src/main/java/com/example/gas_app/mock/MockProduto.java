package com.example.gas_app.mock;

import com.example.gas_app.R;

public class MockProduto {
    public static String[] nome = { "Botijão 8kg", "Botijão 30kg", "Botijão 45kg" };
    public static Double[] preco = { 70.00, 105.00, 300.00 };
    public static Integer[] img = { R.drawable.gas8, R.drawable.gas30, R.drawable.gas45 };
}
